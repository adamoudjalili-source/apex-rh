# ROADMAP.md — APEX RH
> Mis à jour : Session 74 ✅ — Compensation — Workflow révision salariale — DÉPLOYÉ (08/03/2026)

## 🔴 RÈGLE D'OR — LIVRAISON OBLIGATOIRE (chaque session)

1. `MEMOIRE_PROJET_SXX.md` mis à jour
2. `ROADMAP_SXX.md` mis à jour
3. `SESSION_START_SXX+1.md` créé et pré-rempli
4. **ZIP `src_SXX.zip` du dossier `src/` COMPLET**
5. **Commande Git prête à copier-coller**

---

## Modules en production

| Session | Module | Statut |
|---------|--------|--------|
| S1–S73 | (voir MEMOIRE_PROJET_S74.md) | ✅ Production |
| **S74** | **Compensation — Workflow révision salariale** | ✅ **DÉPLOYÉ** |

---

## Session 74 — Livrables ✅

- `s74_compensation_workflow.sql` — enum extension, colonnes workflow, table cycles, MVs, RLS
- `useCompensation.js` — 14 hooks S74 (cycles, workflow 2 niveaux, simulation, stats)
- `RevisionWorkflow.jsx` — workflow demande → validation → application
- `CycleRevision.jsx` — gestion cycles annuels
- `SimulationBudget.jsx` — simulation impact masse salariale
- `CompensationDashboardEnrichi.jsx` — dashboard KPIs révisions
- `Compensation.jsx` — 9 onglets avec badges S74

**Hotfixes appliqués :**
- `review_status` enum : cast `::text` dans MVs (unsafe new enum value)
- `user_id` au lieu de `employee_id` dans compensation_reviews
- `old_base_salary`/`new_base_salary` au lieu de `current_salary`/`new_salary`
- `useTeamRevisionWorkflow` (renommé depuis `useTeamReviews` pour éviter doublon S58)
- `useUsersList` depuis `useSettings` (au lieu de `useOrgUsers` inexistant)

---

## Roadmap S75–S87

| Session | Module | Priorité | Statut |
|---------|--------|----------|--------|
| **S75** | **Onboarding — Parcours progressif automatisé** | 🔴 Haute | 🎯 **Prochaine** |
| S76 | Performance PULSE — Alertes proactives + calibration | 🟠 Moyenne | ⏳ Planifiée |
| S77 | Tâches — Dépendances + récurrence + charge | 🟠 Moyenne | ⏳ Planifiée |
| S78 | OKR — Cycle complet + check-ins + lien évaluation | 🟠 Moyenne | ⏳ Planifiée |
| S79 | Projets — Connexions + budget + Gantt avancé | 🟠 Moyenne | ⏳ Planifiée |
| S80 | Entretiens Annuels — Mi-année + auto-éval + suivi | 🟠 Moyenne | ⏳ Planifiée |
| S81 | Feedback 360° — Cycles planifiés + tendances | 🟡 Basse | ⏳ Planifiée |
| S82 | Intelligence RH — Bilan social + turnover | 🟠 Moyenne | ⏳ Planifiée |
| S83 | Succession & Talents — Vivier + gap analysis | 🟡 Basse | ⏳ Planifiée |
| S84 | Référentiel Compétences — Cartographie + gaps | 🟠 Moyenne | ⏳ Planifiée |
| S85 | Offboarding — Automatisation + solde auto | 🟡 Basse | ⏳ Planifiée |
| S86 | Notifications — Moteur de règles + escalade | 🟠 Moyenne | ⏳ Planifiée |
| S87 | Communication — Ciblage + accusés lecture | 🟡 Basse | ⏳ Planifiée |
